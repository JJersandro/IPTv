# P0ïPo TV

Persoonlijke tv-omgeving bovenop de openbare playlists van [iptv-org](https://github.com/iptv-org/iptv).
Live: https://p0ipo-tv.vercel.app

## Wat zit waar
| Pad | Wat |
|---|---|
| `index.html` | De app (Hearth, Live, speler) |
| `api/p.js` | Stream-proxy: lost CORS en http-op-https op |
| `engine/build-catalog.mjs` | Catalogus-motor: ophalen, indelen, streams testen |
| `engine/taxonomy.json` | Jouw categorieën (Mi Pais, Anime, Football, ...) en hun regels |
| `engine/overrides.json` | Handmatige correcties, winnen altijd |
| `catalog/` | Uitvoer van de motor (wordt elke 6 uur bijgewerkt) |
| `.github/workflows/catalog.yml` | Draait de motor elke 6 uur |

## Eenmalig instellen
1. Maak op GitHub een **publieke** repo `p0ipo-tv` (leeg, zonder README).
2. In deze map: `git remote add origin https://github.com/<jouw-naam>/p0ipo-tv.git && git push -u origin main`
3. Vercel → project **p0ipo-tv** → Settings → Git → koppel de repo. Vanaf nu gaat elke push vanzelf live.
4. GitHub → tab **Actions** → "P0ïPo catalogus" → **Run workflow** voor de eerste catalogus.

## Lokaal testen
`HEALTH_LIMIT=300 node engine/build-catalog.mjs` (test alleen 300 streams).
