// P0ïPo TV stream-proxy: lost CORS en http-op-https (mixed content) op.
// Herschrijft HLS-playlists zodat alle segmenten ook via deze proxy lopen.
export const config = { runtime: 'edge' };

const BLOCKED_HOST = /^(localhost|127\.|10\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[|.*\.local$|.*\.internal$)/i;
const MEDIA_TYPE = /mpegurl|mp2t|video\/|audio\/|octet-stream|binary|dash\+xml|text\/plain|mp4/i;
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'range', 'access-control-expose-headers': 'content-length, content-range' };
const txt = (status, msg) => new Response(msg, { status, headers: { ...cors, 'content-type': 'text/plain; charset=utf-8' } });

function rewrite(body, base, origin) {
  const wrap = (x) => { try { return origin + '/api/p?u=' + encodeURIComponent(new URL(x, base).href); } catch { return x; } };
  return body.split(/\r?\n/).map((line) => {
    const t = line.trim();
    if (!t) return line;
    if (t.startsWith('#')) return line.replace(/URI="([^"]+)"/g, (_, x) => `URI="${wrap(x)}"`);
    return wrap(t);
  }).join('\n');
}

export default async function handler(req) {
  if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
  const self = new URL(req.url);
  let target;
  try { target = new URL(self.searchParams.get('u')); } catch { return txt(400, 'Ongeldige stream-url'); }
  if (!/^https?:$/.test(target.protocol) || BLOCKED_HOST.test(target.hostname)) return txt(403, 'Deze bron is niet toegestaan');

  const headers = { 'user-agent': 'Mozilla/5.0 (P0iPo TV)' };
  const range = req.headers.get('range');
  if (range) headers.range = range;

  let up;
  try { up = await fetch(target, { headers, redirect: 'follow' }); }
  catch { return txt(502, 'Bron onbereikbaar'); }

  const ct = up.headers.get('content-type') || '';
  const finalUrl = up.url || target.href;
  const looksLikeList = /mpegurl/i.test(ct) || /\.m3u8?($|\?)/i.test(new URL(finalUrl).pathname + new URL(finalUrl).search) || /text\/plain/i.test(ct);

  if (looksLikeList) {
    const body = await up.text();
    if (body.trimStart().startsWith('#EXTM3U')) {
      return new Response(rewrite(body, finalUrl, self.origin), {
        status: up.status,
        headers: { ...cors, 'content-type': 'application/vnd.apple.mpegurl', 'cache-control': 'no-store' },
      });
    }
    if (!/mpegurl/i.test(ct)) return txt(415, 'Geen mediastream');
  }

  if (ct && !MEDIA_TYPE.test(ct)) return txt(415, 'Geen mediastream');

  const out = { ...cors, 'content-type': ct || 'application/octet-stream', 'cache-control': 'public, max-age=10' };
  for (const h of ['content-length', 'content-range', 'accept-ranges']) {
    const v = up.headers.get(h); if (v) out[h] = v;
  }
  return new Response(up.body, { status: up.status, headers: out });
}
